﻿namespace AppLista3_Lógica
{
    partial class FrmExerc2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblPrecoL = new System.Windows.Forms.Label();
            this.lblValPag = new System.Windows.Forms.Label();
            this.txtPrecoL = new System.Windows.Forms.TextBox();
            this.txtValPag = new System.Windows.Forms.TextBox();
            this.btnLitros = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblPrecoL
            // 
            this.lblPrecoL.AutoSize = true;
            this.lblPrecoL.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.lblPrecoL.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(159)))), ((int)(((byte)(62)))));
            this.lblPrecoL.Location = new System.Drawing.Point(69, 64);
            this.lblPrecoL.Name = "lblPrecoL";
            this.lblPrecoL.Size = new System.Drawing.Size(101, 20);
            this.lblPrecoL.TabIndex = 0;
            this.lblPrecoL.Text = "Preço do litro";
            // 
            // lblValPag
            // 
            this.lblValPag.AutoSize = true;
            this.lblValPag.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.lblValPag.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(159)))), ((int)(((byte)(62)))));
            this.lblValPag.Location = new System.Drawing.Point(69, 172);
            this.lblValPag.Name = "lblValPag";
            this.lblValPag.Size = new System.Drawing.Size(153, 20);
            this.lblValPag.TabIndex = 1;
            this.lblValPag.Text = "Valor de pagamento";
            // 
            // txtPrecoL
            // 
            this.txtPrecoL.Location = new System.Drawing.Point(72, 113);
            this.txtPrecoL.Name = "txtPrecoL";
            this.txtPrecoL.Size = new System.Drawing.Size(100, 20);
            this.txtPrecoL.TabIndex = 2;
            // 
            // txtValPag
            // 
            this.txtValPag.Location = new System.Drawing.Point(72, 222);
            this.txtValPag.Name = "txtValPag";
            this.txtValPag.Size = new System.Drawing.Size(100, 20);
            this.txtValPag.TabIndex = 3;
            // 
            // btnLitros
            // 
            this.btnLitros.Location = new System.Drawing.Point(341, 172);
            this.btnLitros.Name = "btnLitros";
            this.btnLitros.Size = new System.Drawing.Size(165, 23);
            this.btnLitros.TabIndex = 4;
            this.btnLitros.Text = "Quantidade de Litros";
            this.btnLitros.UseVisualStyleBackColor = true;
            this.btnLitros.Click += new System.EventHandler(this.btnLitros_Click);
            // 
            // FrmExerc2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(92)))), ((int)(((byte)(103)))));
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnLitros);
            this.Controls.Add(this.txtValPag);
            this.Controls.Add(this.txtPrecoL);
            this.Controls.Add(this.lblValPag);
            this.Controls.Add(this.lblPrecoL);
            this.Name = "FrmExerc2";
            this.Text = "FrmExerc2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblPrecoL;
        private System.Windows.Forms.Label lblValPag;
        private System.Windows.Forms.TextBox txtPrecoL;
        private System.Windows.Forms.TextBox txtValPag;
        private System.Windows.Forms.Button btnLitros;
    }
}