﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppLista3_Lógica
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnSoma_Click(object sender, EventArgs e)
        {
            float num1 = float.Parse(txtNum1.Text);
            float num3 = float.Parse(txtNum3.Text);
            float soma;

            soma = num1 + num3;
            MessageBox.Show("O resultado " + soma);
        }

        private void btnMedia_Click(object sender, EventArgs e)
        {
            float num1 = float.Parse(txtNum1.Text);
            float num2 = float.Parse(txtNum2.Text);
            float num3 = float.Parse(txtNum3.Text);
            float media;

            media = (num1 + num2 + num3) / 3;
            MessageBox.Show("O resultado " + media);
        }

        private void btnPorcento_Click(object sender, EventArgs e)
        {
            float num1 = float.Parse(txtNum1.Text);
            float num2 = float.Parse(txtNum2.Text);
            float num3 = float.Parse(txtNum3.Text);
            float porcento1 = (num1 + num2 + num3) / 100 *num1;
            float porcento2 = (num1 + num2 + num3) / 100 * num2;
            float porcento3 = (num1 + num2 + num3) / 100 * num3;


            MessageBox.Show("As porcentagens são " + porcento1 + ", " + porcento2 + ", " + porcento3);
        }
    }
}
