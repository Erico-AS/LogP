﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppLista3_Lógica
{
    public partial class FrmExerc2 : Form
    {
        public FrmExerc2()
        {
            InitializeComponent();
        }

        private void btnLitros_Click(object sender, EventArgs e)
        {
            float PrecoL = float.Parse(txtPrecoL.Text);
            float ValPag = float.Parse(txtValPag.Text);
            float Litros;

            Litros = ValPag / PrecoL;
            MessageBox.Show(Litros + "L");
        }
    }
}
